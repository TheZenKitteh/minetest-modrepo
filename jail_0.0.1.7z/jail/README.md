The idea hit me earlier tonight when building a small town on the DTAmedia server.. why isn't there a jail mod? With the help of kaeza (thank you again) this mod was born.

What does it do? It allows anyone with the "jail" priv to send players to jail and release them from jail. Every 30 seconds it sends prisoners back to jail (in case they escape). You can edit the init.lua file to change how often it sends the prisoners to jail and also the jail coordinates. This mod also adds unbreakable jail wall, jail glass, jail bars and a warden pick (for breaking said unbreakable blocks).

To send someone to jail, do:
/jail playername

To release someone from jail do:
/release playername

To grant someone the priv to send someone to jail and release them do:
/grant playername jail

To get jail wall, glass, bars or pick:
/giveme wardenpick
/giveme jail:jailwall
/giveme jail:glass
/giveme jail:ironbars

You MUST build a jail before you can send someone to jail! (this shouldn't have to be mentioned but mentioning it anyway).

No screenshots are offered since theres nothing really to screenshot.

Feel free to offer better textures and any ideas. Also report any issues.
