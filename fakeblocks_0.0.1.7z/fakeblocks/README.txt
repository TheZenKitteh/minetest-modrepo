Created by RAPHAEL, inspired by trade craft.

For a fake block to "work" you must have the mod for that
block installed.

Example: Say you want a fake industrial:cement block. You
		 will need to have the industrial mod installed
		 to use the fake block or it will not have proper
		 textures.


Mods covered:
* various
* industrial
* moreblocks
* obsidian
More to come?


Crafting is simple. Put the supported block that you want
a fake of in crafting table. Surround it with sand.
S=Sand
B=Block

S	S	S
S	B	S
S	S	S
