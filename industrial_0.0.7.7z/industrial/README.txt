Look into the init.lua file for specific names and recipes if needed.

Screenshot: To Be done...

TODO (or attempt):
* refrigerator, stove, sink blocks
* better industrial lighting
* better graphics
* desks and chairs

Now onto what you can do:
* crates (top row wood (3), center row middle wood (1), bottom row wood (3))
* safes (top row wood (3), center middle row steel ingot (1), bottom row wood(3))
* asphalt (2 coal lump side by side and 2 gravel side by side)
* "steel gray" block (3 steel blocks in a horizontal row)
* filing cabinets (2 tumbas in a horizontal row)
* Railroad crossing sign (rail and sign side by side)
* Exit sign (wood and sign side by side)
* Dead End sign (asphalt and sign side by side)
* [disabled by default] High voltage sign (mesecon and sign side by side)
* Cement block (for looks, looks like cement, works with included cement mod or alone)
* White Brick (I missed it, 4 stone in a square)
