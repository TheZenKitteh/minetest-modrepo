Originally made by mauvebic but apparently abandoned.
It has been updated to work with latest minetest.


Replicates whatever node its placed on. Doesnt replicate
tools, signs, torches things of that nature (non cubic
nodes). Must dig replicated material to continue
generating more.
