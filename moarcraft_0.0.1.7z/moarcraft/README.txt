A simple mod to add various things.
See init.lua for details.

This mod was originally named and posted by
VlAleVas but apparently abandoned. Originally it had
two crafting recipes and has since been expanded
and will be expanded further.
